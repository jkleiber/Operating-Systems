Project 4

Name: Justin Kleiber

Email address: jkleiber@ou.edu | jkleiber8@gmail.com

Date: 11/15/2018

Description
I have built on my project 3 code for this project. My ztouch function
uses the fopen and fclose functions provided in the API, which I have coded.
My code from project 3 needed some minor adjustments to handle the files in
the file system (i.e. not assuming everything is a directory).

References
So far I have only discussed the project in passing with Trey Sullivent

