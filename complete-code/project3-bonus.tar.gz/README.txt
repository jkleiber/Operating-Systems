Project 3

Name: Justin Kleiber

Email address: jkleiber@ou.edu | jkleiber8@gmail.com

Date: 10/21/2018

Description
For the OUFS filesystem, I have developed code that interacts
with a virtual disk. This code is based off of the framework
posted on the course webpage, and currently implements the
zinspect and zformat commands.

References
So far, I have only needed to use the project webpage.