#!/bin/bash

cp zinspect /projects/3/
cp zformat /projects/3/
cp zfilez /projects/3/
cp zmkdir /projects/3/
cp zrmdir /projects/3/
cp *.c /projects/3/
cp *.h /projects/3/
cp README.txt /projects/3/
cp Makefile /projects/3/

#change permissions
#chmod 777 /projects --recursive
#chgrp google-sudoers /projects --recursive
